package com.tout;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ToutApplicationTests {

    @Test
    void contextLoads() {
    }

}
